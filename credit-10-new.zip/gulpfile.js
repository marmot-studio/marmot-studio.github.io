'use strict';

// Load plugins
const autoprefixer = require('autoprefixer');
const browsersync = require('browser-sync').create();
const cssnano = require('cssnano');
const gulp = require('gulp');
const cached = require('gulp-cached');
const dependents = require('gulp-dependents');
const plumber = require('gulp-plumber');
const postcss = require('gulp-postcss');
const rename = require('gulp-rename');
const sass = require('gulp-sass');
const svgSprite = require('gulp-svg-sprite');
const posthtml = require('gulp-posthtml');
const beautify = require('posthtml-beautify');
const include = require('posthtml-include');
const mqpacker = require('css-mqpacker');
const path = require('path');

const paths = {
  src: {
    html: 'src/html/',
    partials: 'src/html/partials/',
    css: 'src/scss/',
    icons: 'src/icons/'
  },
  dest: {
    html: '.',
    css: 'assets/css/'
  }
};

// BrowserSync
function browserSync(done) {
  browsersync.init({
    server: {
      baseDir: './'
    },
    port: 3000
  });
  done();
}

// BrowserSync Reload
function browserSyncReload(done) {
  browsersync.reload();
  done();
}

// CSS task
function css() {
  return gulp
    .src([paths.src.css + '**/*.scss', '!' + paths.src.css + 'vendors/**/*.scss'])
    .pipe(plumber())
    .pipe(cached('styles'))
    .pipe(dependents())
    .pipe(sass({
      outputStyle: 'expanded'
    }))
    .pipe(postcss([autoprefixer({
      browsers: ['last 2 versions', '> 1%'],
      cascade: false
    }), mqpacker({sort: true})]))
    .pipe(gulp.dest(paths.dest.css))
    // .pipe(postcss([cssnano()]))
    // .pipe(rename({suffix: '.min'}))
    // .pipe(gulp.dest(paths.dest.css))
    .pipe(browsersync.stream());
}

function html() {
  return gulp
    .src(paths.src.html + '**/[^_]*.html')
    .pipe(posthtml([
      include({
        root: paths.src.partials
      }),
      beautify({
        rules: {
          blankLines: false
        }
      })
    ]))
    .pipe(gulp.dest(paths.dest.html))
    .pipe(browsersync.stream());
}

// SVG
function svg() {
  return gulp
    .src(paths.src.icons + 'lang/*.svg')
    .pipe(svgSprite({
      shape: {
        dimension: {
          maxWidth: 16,
          maxHeight: 16
        }
      },
      svg: {
        xmlDeclaration: false,
        doctypeDeclaration: false,
        rootAttributes: {
          id: 'sprite'
        }
      },
      mode: {
        symbol: {
          dest: '.',
          sprite: paths.src.icons + 'sprite.svg',
          render: {
            scss: {
              dest: paths.src.css + '_svg-sprite.scss',
              template: paths.src.icons + 'svg-sprite-template.scss'
            }
          }
        }
      }
    }))
    .pipe(gulp.dest('.'));
}

// Watch files
function watchFiles() {
  gulp.watch(paths.src.css + '**/*', {delay: 400}, css).on('unlink', function(filepath) {
    delete cached.caches.styles[path.resolve(filepath)];
  });
  gulp.watch(paths.src.html + '**/*', html);
  gulp.watch('./*.html', browserSyncReload);
}

// Define complex tasks
const watch = gulp.parallel(watchFiles, browserSync);

// Export tasks
exports.html = html;
exports.css = css;
exports.svg = svg;
exports.default = watch;